package Ventana;

public class JFrame {

	public JFrame(String string) {
		// TODO Auto-generated constructor stub
	}

}
